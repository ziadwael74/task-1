# ECU Summer 2026 - Learning Management System API

A curriculum-level REST API for a Learning Management System.

The project is intentionally kept at the same student/backend level as the reference ECU E-Commerce project:
- Node.js
- Express.js
- MongoDB
- Mongoose
- Multer
- dotenv
- cors
- REST APIs
- CRUD
- Mongoose references
- Middleware
- Simple header-based user identification with `x-user-id`

## Roles

### Admin
- Manage users
- Manage categories
- Create, update and delete courses
- View courses

### Instructor
- Create courses
- View courses
- Update own courses
- Delete own courses
- Upload course images

### Student
- View courses
- View course details
- Enroll in courses
- View own enrollments

## Models

### User
- name
- email
- password
- role
- image

### Category
- name
- description

### Course
- title
- description
- price
- category -> Category
- instructor -> User
- image
- timestamps

### Enrollment
- student -> User
- course -> Course
- enrolledAt
- timestamps

## Authentication

This project does not use JWT or bcrypt.

Protected requests send:

`x-user-id: <MongoDB User _id>`

The middleware:
1. Reads `x-user-id`.
2. Finds the User in MongoDB.
3. Stores the user in `req.user`.
4. Checks the required role.
5. Allows or rejects the request.

## API Endpoints

### Users
- POST `/api/users`
- GET `/api/users`
- GET `/api/users/:id`
- PATCH `/api/users/:id`
- DELETE `/api/users/:id`

### Categories
- POST `/api/categories`
- GET `/api/categories`
- GET `/api/categories/:id`
- PATCH `/api/categories/:id`
- DELETE `/api/categories/:id`

### Courses
- POST `/api/courses`
- GET `/api/courses`
- GET `/api/courses/:id`
- PATCH `/api/courses/:id`
- DELETE `/api/courses/:id`

Optional course query:
- `/api/courses?search=node`
- `/api/courses?category=<categoryId>`

### Enrollments
- POST `/api/enrollments`
- GET `/api/enrollments`
- GET `/api/enrollments/:id`

## Course Image Upload

Course creation/update accepts `multipart/form-data`.

Field name:

`image`

Images are stored locally in:

`uploads/courses/`

Allowed image types:
- JPG
- JPEG
- PNG

Maximum file size:
- 5 MB

The stored path is saved in `Course.image`.

## Setup

1. Install Node.js and MongoDB.
2. Copy `.env.example` to `.env`.
3. Update the MongoDB connection if needed.
4. Install packages:

`npm install`

5. Start development server:

`npm run dev`

Server:

`http://localhost:5000`

## Postman

Import:

`postman/ECU_LMS_API.postman_collection.json`

Create the three users first, then put their MongoDB IDs into:
- `adminId`
- `instructorId`
- `studentId`

Then create a category and put its ID into `categoryId`.

Create a course and put its ID into `courseId`.

Then test enrollment.

## Curriculum Scope

Deliberately not used:
- JWT
- jsonwebtoken
- bcrypt
- bcryptjs
- OAuth
- Passport.js
- refresh/access tokens
- Redis
- Docker
- TypeScript
- Prisma
- Sequelize
- GraphQL
- WebSockets
- Firebase
- Cloudinary
- AWS
- Microservices
- Repository pattern
- Dependency injection
- advanced authentication
- advanced security
- payments
- notifications
- recommendations
- analytics
- real-time chat
- video streaming
- caching
- AI features
