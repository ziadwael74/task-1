const ApiResponse = require("../utils/apiResponse");

const notFound = (req, res) => {
    return ApiResponse.error(res, `Route not found: ${req.originalUrl}`, 404);
};

const errorHandler = (err, req, res, next) => {
    console.error(err);

    if (err.name === "ValidationError") {
        const messages = Object.values(err.errors).map((item) => item.message);
        return ApiResponse.error(res, messages.join(", "), 400);
    }

    if (err.name === "CastError") {
        return ApiResponse.error(res, "Invalid ID", 400);
    }

    if (err.code === 11000) {
        return ApiResponse.error(res, "Duplicate value already exists", 400);
    }

    if (err.message && err.message.includes("Only JPG")) {
        return ApiResponse.error(res, err.message, 400);
    }

    return ApiResponse.error(res, err.message || "Internal server error", 500);
};

module.exports = {
    notFound,
    errorHandler
};
