const User = require("../models/User");
const ApiResponse = require("../utils/apiResponse");

const protect = async (req, res, next) => {
    try {
        const userId = req.headers["x-user-id"];

        if (!userId) {
            return ApiResponse.error(res, "x-user-id header is required", 401);
        }

        const user = await User.findById(userId);

        if (!user) {
            return ApiResponse.error(res, "User not found", 401);
        }

        req.user = user;
        next();
    } catch (error) {
        next(error);
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return ApiResponse.error(res, "You are not authorized to perform this action", 403);
        }

        next();
    };
};

module.exports = {
    protect,
    authorize
};
