const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema(
    {
        title: {
            type: String,
            required: [true, "Course title is required"],
            trim: true
        },
        description: {
            type: String,
            required: [true, "Course description is required"]
        },
        price: {
            type: Number,
            required: [true, "Course price is required"],
            min: [0, "Price cannot be negative"]
        },
        category: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Category",
            required: [true, "Course category is required"]
        },
        instructor: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: [true, "Course instructor is required"]
        },
        image: {
            type: String,
            default: "/uploads/courses/default-course.png"
        }
    },
    {
        timestamps: true
    }
);

courseSchema.index({
    title: "text",
    description: "text"
});

const Course = mongoose.model("Course", courseSchema);

module.exports = Course;
