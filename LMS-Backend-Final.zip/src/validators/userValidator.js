const validateUser = (req, res, next) => {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({
            success: false,
            message: "Name, email and password are required"
        });
    }

    if (role && !["Admin", "Instructor", "Student"].includes(role)) {
        return res.status(400).json({
            success: false,
            message: "Invalid user role"
        });
    }

    next();
};

module.exports = validateUser;
