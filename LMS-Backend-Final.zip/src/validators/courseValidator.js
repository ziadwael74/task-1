const validateCourse = (req, res, next) => {
    const { title, description, price, category } = req.body;

    if (!title || !description || price === undefined || !category) {
        return res.status(400).json({
            success: false,
            message: "Title, description, price and category are required"
        });
    }

    if (Number.isNaN(Number(price)) || Number(price) < 0) {
        return res.status(400).json({
            success: false,
            message: "Price must be a non-negative number"
        });
    }

    next();
};

module.exports = validateCourse;
