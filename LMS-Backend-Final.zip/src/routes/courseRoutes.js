const express = require("express");
const {
    createCourse,
    getCourses,
    getCourseById,
    updateCourse,
    deleteCourse
} = require("../controllers/courseController");
const { protect, authorize } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");
const validateCourse = require("../validators/courseValidator");

const router = express.Router();

router.get("/", getCourses);
router.get("/:id", getCourseById);

router.post(
    "/",
    protect,
    authorize("Admin", "Instructor"),
    upload.single("image"),
    validateCourse,
    createCourse
);

router.patch(
    "/:id",
    protect,
    authorize("Admin", "Instructor"),
    upload.single("image"),
    updateCourse
);

router.delete(
    "/:id",
    protect,
    authorize("Admin", "Instructor"),
    deleteCourse
);

module.exports = router;
