const express = require("express");
const {
    createUser,
    getUsers,
    getUserById,
    updateUser,
    deleteUser
} = require("../controllers/userController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validateUser = require("../validators/userValidator");

const router = express.Router();

router.post("/", validateUser, createUser);
router.get("/", protect, authorize("Admin"), getUsers);
router.get("/:id", protect, getUserById);
router.patch("/:id", protect, updateUser);
router.delete("/:id", protect, authorize("Admin"), deleteUser);

module.exports = router;
