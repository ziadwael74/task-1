const express = require("express");
const {
    createEnrollment,
    getMyEnrollments,
    getEnrollmentById
} = require("../controllers/enrollmentController");
const { protect, authorize } = require("../middleware/authMiddleware");

const router = express.Router();

router.post(
    "/",
    protect,
    authorize("Student"),
    createEnrollment
);

router.get(
    "/",
    protect,
    authorize("Student", "Admin"),
    getMyEnrollments
);

router.get(
    "/:id",
    protect,
    authorize("Student", "Admin"),
    getEnrollmentById
);

module.exports = router;
