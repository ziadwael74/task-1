const express = require("express");
const {
    createCategory,
    getCategories,
    getCategoryById,
    updateCategory,
    deleteCategory
} = require("../controllers/categoryController");
const { protect, authorize } = require("../middleware/authMiddleware");
const validateCategory = require("../validators/categoryValidator");

const router = express.Router();

router.get("/", getCategories);
router.get("/:id", getCategoryById);

router.post(
    "/",
    protect,
    authorize("Admin"),
    validateCategory,
    createCategory
);

router.patch(
    "/:id",
    protect,
    authorize("Admin"),
    validateCategory,
    updateCategory
);

router.delete(
    "/:id",
    protect,
    authorize("Admin"),
    deleteCategory
);

module.exports = router;
