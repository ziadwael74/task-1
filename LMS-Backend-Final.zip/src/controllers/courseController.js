const Course = require("../models/Course");
const Category = require("../models/Category");
const ApiResponse = require("../utils/apiResponse");

const createCourse = async (req, res, next) => {
    try {
        const { title, description, price, category } = req.body;

        const categoryExists = await Category.findById(category);

        if (!categoryExists) {
            return ApiResponse.error(res, "Specified category does not exist", 404);
        }

        const image = req.file
            ? `/uploads/courses/${req.file.filename}`
            : "/uploads/courses/default-course.png";

        const course = await Course.create({
            title,
            description,
            price: Number(price),
            category,
            instructor: req.user._id,
            image
        });

        const populatedCourse = await course.populate([
            { path: "category", select: "name description" },
            { path: "instructor", select: "name email role" }
        ]);

        return ApiResponse.success(
            res,
            "Course created successfully",
            { course: populatedCourse },
            201
        );
    } catch (error) {
        next(error);
    }
};

const getCourses = async (req, res, next) => {
    try {
        const { search, category } = req.query;

        const filter = {};

        if (category) {
            filter.category = category;
        }

        if (search) {
            filter.$or = [
                { title: { $regex: search, $options: "i" } },
                { description: { $regex: search, $options: "i" } }
            ];
        }

        const courses = await Course.find(filter)
            .populate("category", "name description")
            .populate("instructor", "name email role")
            .sort({ createdAt: -1 });

        return ApiResponse.success(res, "Courses retrieved successfully", {
            count: courses.length,
            courses
        });
    } catch (error) {
        next(error);
    }
};

const getCourseById = async (req, res, next) => {
    try {
        const course = await Course.findById(req.params.id)
            .populate("category", "name description")
            .populate("instructor", "name email role");

        if (!course) {
            return ApiResponse.error(res, "Course not found", 404);
        }

        return ApiResponse.success(res, "Course retrieved successfully", {
            course
        });
    } catch (error) {
        next(error);
    }
};

const updateCourse = async (req, res, next) => {
    try {
        const course = await Course.findById(req.params.id);

        if (!course) {
            return ApiResponse.error(res, "Course not found", 404);
        }

        if (
            req.user.role !== "Admin" &&
            course.instructor.toString() !== req.user._id.toString()
        ) {
            return ApiResponse.error(
                res,
                "You can only update your own course",
                403
            );
        }

        if (req.body.category) {
            const categoryExists = await Category.findById(req.body.category);

            if (!categoryExists) {
                return ApiResponse.error(
                    res,
                    "Specified category does not exist",
                    404
                );
            }

            course.category = req.body.category;
        }

        if (req.body.title) course.title = req.body.title;
        if (req.body.description) course.description = req.body.description;
        if (req.body.price !== undefined) course.price = Number(req.body.price);

        if (req.file) {
            course.image = `/uploads/courses/${req.file.filename}`;
        }

        await course.save();

        const updatedCourse = await course.populate([
            { path: "category", select: "name description" },
            { path: "instructor", select: "name email role" }
        ]);

        return ApiResponse.success(res, "Course updated successfully", {
            course: updatedCourse
        });
    } catch (error) {
        next(error);
    }
};

const deleteCourse = async (req, res, next) => {
    try {
        const course = await Course.findById(req.params.id);

        if (!course) {
            return ApiResponse.error(res, "Course not found", 404);
        }

        if (
            req.user.role !== "Admin" &&
            course.instructor.toString() !== req.user._id.toString()
        ) {
            return ApiResponse.error(
                res,
                "You can only delete your own course",
                403
            );
        }

        await course.deleteOne();

        return ApiResponse.success(res, "Course deleted successfully");
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createCourse,
    getCourses,
    getCourseById,
    updateCourse,
    deleteCourse
};
