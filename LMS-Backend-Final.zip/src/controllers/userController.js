const User = require("../models/User");
const ApiResponse = require("../utils/apiResponse");

const createUser = async (req, res, next) => {
    try {
        const user = await User.create(req.body);

        return ApiResponse.success(
            res,
            "User created successfully",
            { user },
            201
        );
    } catch (error) {
        next(error);
    }
};

const getUsers = async (req, res, next) => {
    try {
        const users = await User.find().select("-password").sort({ createdAt: -1 });

        return ApiResponse.success(res, "Users retrieved successfully", {
            count: users.length,
            users
        });
    } catch (error) {
        next(error);
    }
};

const getUserById = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id).select("-password");

        if (!user) {
            return ApiResponse.error(res, "User not found", 404);
        }

        return ApiResponse.success(res, "User retrieved successfully", { user });
    } catch (error) {
        next(error);
    }
};

const updateUser = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id);

        if (!user) {
            return ApiResponse.error(res, "User not found", 404);
        }

        if (req.body.name) user.name = req.body.name;
        if (req.body.email) user.email = req.body.email;
        if (req.body.password) user.password = req.body.password;
        if (req.body.role) user.role = req.body.role;

        await user.save();

        const safeUser = user.toObject();
        delete safeUser.password;

        return ApiResponse.success(res, "User updated successfully", {
            user: safeUser
        });
    } catch (error) {
        next(error);
    }
};

const deleteUser = async (req, res, next) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);

        if (!user) {
            return ApiResponse.error(res, "User not found", 404);
        }

        return ApiResponse.success(res, "User deleted successfully");
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createUser,
    getUsers,
    getUserById,
    updateUser,
    deleteUser
};
