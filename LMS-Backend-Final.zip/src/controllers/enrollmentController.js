const Enrollment = require("../models/Enrollment");
const Course = require("../models/Course");
const ApiResponse = require("../utils/apiResponse");

const createEnrollment = async (req, res, next) => {
    try {
        const { course } = req.body;

        if (!course) {
            return ApiResponse.error(res, "Course is required", 400);
        }

        const courseExists = await Course.findById(course);

        if (!courseExists) {
            return ApiResponse.error(res, "Course not found", 404);
        }

        const alreadyEnrolled = await Enrollment.findOne({
            student: req.user._id,
            course
        });

        if (alreadyEnrolled) {
            return ApiResponse.error(
                res,
                "You are already enrolled in this course",
                400
            );
        }

        const enrollment = await Enrollment.create({
            student: req.user._id,
            course
        });

        const populatedEnrollment = await enrollment.populate([
            { path: "student", select: "name email role" },
            {
                path: "course",
                select: "title description price image category instructor"
            }
        ]);

        return ApiResponse.success(
            res,
            "Enrollment created successfully",
            { enrollment: populatedEnrollment },
            201
        );
    } catch (error) {
        next(error);
    }
};

const getMyEnrollments = async (req, res, next) => {
    try {
        const enrollments = await Enrollment.find({
            student: req.user._id
        })
            .populate("course", "title description price image category instructor")
            .sort({ createdAt: -1 });

        return ApiResponse.success(res, "Enrollments retrieved successfully", {
            count: enrollments.length,
            enrollments
        });
    } catch (error) {
        next(error);
    }
};

const getEnrollmentById = async (req, res, next) => {
    try {
        const enrollment = await Enrollment.findById(req.params.id)
            .populate("student", "name email role")
            .populate("course", "title description price image category instructor");

        if (!enrollment) {
            return ApiResponse.error(res, "Enrollment not found", 404);
        }

        if (
            req.user.role !== "Admin" &&
            enrollment.student._id.toString() !== req.user._id.toString()
        ) {
            return ApiResponse.error(res, "You are not authorized", 403);
        }

        return ApiResponse.success(res, "Enrollment retrieved successfully", {
            enrollment
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createEnrollment,
    getMyEnrollments,
    getEnrollmentById
};
